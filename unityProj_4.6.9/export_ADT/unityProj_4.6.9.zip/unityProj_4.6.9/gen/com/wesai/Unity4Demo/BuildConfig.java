/** Automatically generated file. DO NOT MODIFY */
package com.wesai.Unity4Demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}