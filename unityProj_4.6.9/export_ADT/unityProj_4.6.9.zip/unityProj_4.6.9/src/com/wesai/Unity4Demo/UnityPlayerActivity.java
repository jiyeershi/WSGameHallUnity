package com.wesai.Unity4Demo;

import com.unity3d.player.*;

/**
 * @deprecated Use UnityPlayerNativeActivity instead.
 */
public class UnityPlayerActivity extends UnityPlayerNativeActivity { }